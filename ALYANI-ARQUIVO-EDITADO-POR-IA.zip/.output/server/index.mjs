globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-07-04T16:38:34.000Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/assets/arrow-left-DWsA1N-W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-RAk+hnR5hj9ik2cs2YpKos3vwVM\"",
		"mtime": "2026-07-09T15:34:51.058Z",
		"size": 165,
		"path": "../public/assets/arrow-left-DWsA1N-W.js"
	},
	"/assets/animated-page-DEr0CE_U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"184-SCYByDg7jJQnA8vrG/rgisUmMF8\"",
		"mtime": "2026-07-09T15:34:51.053Z",
		"size": 388,
		"path": "../public/assets/animated-page-DEr0CE_U.js"
	},
	"/assets/auth-7F8HZC2A.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"288f-WpZsskIiudVtBBnH5DVIC9Wzoy0\"",
		"mtime": "2026-07-09T15:34:51.063Z",
		"size": 10383,
		"path": "../public/assets/auth-7F8HZC2A.js"
	},
	"/assets/button-b2dqjJB2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7a97-kFoVDf0T+yw/2HeBdANf4TAoJeM\"",
		"mtime": "2026-07-09T15:34:51.064Z",
		"size": 31383,
		"path": "../public/assets/button-b2dqjJB2.js"
	},
	"/assets/configuracoes-D2B3yCsJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3df-dO5mBGAAM2GxYyFBDQak9aw+dWk\"",
		"mtime": "2026-07-09T15:34:51.081Z",
		"size": 991,
		"path": "../public/assets/configuracoes-D2B3yCsJ.js"
	},
	"/assets/cobrancas-BBhSNDwr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18db-2Na+CsGFBkF0MmlZZ9GMKAWxSbU\"",
		"mtime": "2026-07-09T15:34:51.077Z",
		"size": 6363,
		"path": "../public/assets/cobrancas-BBhSNDwr.js"
	},
	"/assets/conferencia-BraxsG2d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13f6-CkgA/dTf6Io9Mo7SDe58qqBjpTk\"",
		"mtime": "2026-07-09T15:34:51.079Z",
		"size": 5110,
		"path": "../public/assets/conferencia-BraxsG2d.js"
	},
	"/assets/createLucideIcon-DeQrcgrh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-cR1PODv03KUfJz4HloEEypYngbs\"",
		"mtime": "2026-07-09T15:34:51.082Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-DeQrcgrh.js"
	},
	"/assets/clipboard-list-Cmh-2VMV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19b-LvFvyuMqWpZ2ZyJwPDJcjaIj4G0\"",
		"mtime": "2026-07-09T15:34:51.066Z",
		"size": 411,
		"path": "../public/assets/clipboard-list-Cmh-2VMV.js"
	},
	"/assets/custos-D75u5Pdz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1106-h44GyMy84g/scfjf9b3KhjZwUYc\"",
		"mtime": "2026-07-09T15:34:51.084Z",
		"size": 4358,
		"path": "../public/assets/custos-D75u5Pdz.js"
	},
	"/assets/dialog-BwEDc8uH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"83a-8X6Ag2f5HFR4gk/zYPdy20oJ8Xo\"",
		"mtime": "2026-07-09T15:34:51.092Z",
		"size": 2106,
		"path": "../public/assets/dialog-BwEDc8uH.js"
	},
	"/assets/dashboard-BXbBhJAq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17c2-WStd7YK+7xqGQWHC6C7Qbe2BX2k\"",
		"mtime": "2026-07-09T15:34:51.090Z",
		"size": 6082,
		"path": "../public/assets/dashboard-BXbBhJAq.js"
	},
	"/assets/dist-Cyq2gE0m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10cd-Ucat/kHZbDNx/riPqtdjd+6m4Nc\"",
		"mtime": "2026-07-09T15:34:51.095Z",
		"size": 4301,
		"path": "../public/assets/dist-Cyq2gE0m.js"
	},
	"/assets/dist-5uUCy-3J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1396-pJ53li2at1++2ge8eqiAx3e7enc\"",
		"mtime": "2026-07-09T15:34:51.093Z",
		"size": 5014,
		"path": "../public/assets/dist-5uUCy-3J.js"
	},
	"/assets/dist-oL771VFr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25b-tJ6eqfPs+5Lf+7Ei4EXRNzxdinc\"",
		"mtime": "2026-07-09T15:34:51.098Z",
		"size": 603,
		"path": "../public/assets/dist-oL771VFr.js"
	},
	"/assets/dist-lsUx7UVj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"546-udOgIH0q2gVCHvdqwyWF9RAT3xs\"",
		"mtime": "2026-07-09T15:34:51.097Z",
		"size": 1350,
		"path": "../public/assets/dist-lsUx7UVj.js"
	},
	"/assets/es2015-3FDMFG53.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50c9-ah+AsVeDgST/RsKKb3o+jsrzRfM\"",
		"mtime": "2026-07-09T15:34:51.099Z",
		"size": 20681,
		"path": "../public/assets/es2015-3FDMFG53.js"
	},
	"/assets/format-BDHwEjtS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e7-v6ib/T/68vSJrAnClRb41O4oCs8\"",
		"mtime": "2026-07-09T15:34:51.110Z",
		"size": 743,
		"path": "../public/assets/format-BDHwEjtS.js"
	},
	"/assets/hoteis-DBttcBCo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15db-rdU8gQCVPjwUfVQpgPUscXrIGk0\"",
		"mtime": "2026-07-09T15:34:51.111Z",
		"size": 5595,
		"path": "../public/assets/hoteis-DBttcBCo.js"
	},
	"/assets/input-BQh79WNK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26e-aocS77cIQ3+Njwkenj52gNZwCHM\"",
		"mtime": "2026-07-09T15:34:51.114Z",
		"size": 622,
		"path": "../public/assets/input-BQh79WNK.js"
	},
	"/assets/hotel-CBPREwA9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f5d-vax/7VyjRDhlR3YWpLHZQNjpSwY\"",
		"mtime": "2026-07-09T15:34:51.113Z",
		"size": 8029,
		"path": "../public/assets/hotel-CBPREwA9.js"
	},
	"/assets/filter-bar-C5_dEE2n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7d7-/DKuTh3GxazuThalKtBkbY7p4s0\"",
		"mtime": "2026-07-09T15:34:51.108Z",
		"size": 2007,
		"path": "../public/assets/filter-bar-C5_dEE2n.js"
	},
	"/assets/index-DzyFWv53.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"87421-D1Pmsmo/tE9QCrV/nZRhUccORpQ\"",
		"mtime": "2026-07-09T15:34:51.049Z",
		"size": 554017,
		"path": "../public/assets/index-DzyFWv53.js"
	},
	"/assets/jsx-runtime-bzQ4Vb5N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d8-vMfP+4a4ykIjbw4InHkj3E5HWt0\"",
		"mtime": "2026-07-09T15:34:51.116Z",
		"size": 8408,
		"path": "../public/assets/jsx-runtime-bzQ4Vb5N.js"
	},
	"/assets/link-_eKo47Xq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5923-2QxxInMOPqIXvAXwKc82MLE/+yg\"",
		"mtime": "2026-07-09T15:34:51.124Z",
		"size": 22819,
		"path": "../public/assets/link-_eKo47Xq.js"
	},
	"/assets/pagamentos-BnzBcc9Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1852-M3Be60GAD/O7itczecidy4bkq90\"",
		"mtime": "2026-07-09T15:34:51.127Z",
		"size": 6226,
		"path": "../public/assets/pagamentos-BnzBcc9Q.js"
	},
	"/assets/log-out-DoLQqS8K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e6-F7daWOysjZkw9NclzECfGUm4oIs\"",
		"mtime": "2026-07-09T15:34:51.126Z",
		"size": 230,
		"path": "../public/assets/log-out-DoLQqS8K.js"
	},
	"/assets/page-header--CG31WIe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e4-JKksiDRX0oQirsW01G8mlbz9XzI\"",
		"mtime": "2026-07-09T15:34:51.128Z",
		"size": 484,
		"path": "../public/assets/page-header--CG31WIe.js"
	},
	"/assets/pencil-Hsojz1o8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"114-oGD7SpI1Ka3I55ZGRgUgWnrgGNk\"",
		"mtime": "2026-07-09T15:34:51.131Z",
		"size": 276,
		"path": "../public/assets/pencil-Hsojz1o8.js"
	},
	"/assets/plus-psvog1OK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-2H/bO/eVWNBX5A0ZChn5t+59CVA\"",
		"mtime": "2026-07-09T15:34:51.132Z",
		"size": 153,
		"path": "../public/assets/plus-psvog1OK.js"
	},
	"/assets/precos-Bfs6loEY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"135d-u3L2DYMAUxiTkaaHNfs7+N9uLn4\"",
		"mtime": "2026-07-09T15:34:51.138Z",
		"size": 4957,
		"path": "../public/assets/precos-Bfs6loEY.js"
	},
	"/assets/prestadoras-Bv9vxCKg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"172e-k3fPZwAxfmTMCSlJmUtnn6Emd98\"",
		"mtime": "2026-07-09T15:34:51.140Z",
		"size": 5934,
		"path": "../public/assets/prestadoras-Bv9vxCKg.js"
	},
	"/assets/react-dom-DUKFG4MT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dda-2jwqka4uWIJMCW44vChkyRB+fA4\"",
		"mtime": "2026-07-09T15:34:51.144Z",
		"size": 3546,
		"path": "../public/assets/react-dom-DUKFG4MT.js"
	},
	"/assets/printer--2PazsfP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13f-60XnNzbkJJSrGCtkcq+noAJAJT8\"",
		"mtime": "2026-07-09T15:34:51.142Z",
		"size": 319,
		"path": "../public/assets/printer--2PazsfP.js"
	},
	"/assets/relatorios-BYpOzRK-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e6-2qqboYlKlcpkbIWgO4ZtKWcVnZ0\"",
		"mtime": "2026-07-09T15:34:51.145Z",
		"size": 2278,
		"path": "../public/assets/relatorios-BYpOzRK-.js"
	},
	"/assets/roll-alyani._id-G6LQ-KK-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"279e-wGChMfAlT6YNKbEoISl4AlNKjag\"",
		"mtime": "2026-07-09T15:34:51.148Z",
		"size": 10142,
		"path": "../public/assets/roll-alyani._id-G6LQ-KK-.js"
	},
	"/assets/pecas-zEXLucBj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"efa-Or7i8Dvj9CAYAD97d/7b4AEM/jA\"",
		"mtime": "2026-07-09T15:34:51.130Z",
		"size": 3834,
		"path": "../public/assets/pecas-zEXLucBj.js"
	},
	"/assets/roll-alyani-Aq58wVPz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2dde-0j9W7xQvskUo5PG5pa3qWV1oRIE\"",
		"mtime": "2026-07-09T15:34:51.147Z",
		"size": 11742,
		"path": "../public/assets/roll-alyani-Aq58wVPz.js"
	},
	"/assets/roll-prestadora-CZ9wHVZH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f2f-tM77T87set621qxv7MXutW5dAr8\"",
		"mtime": "2026-07-09T15:34:51.149Z",
		"size": 7983,
		"path": "../public/assets/roll-prestadora-CZ9wHVZH.js"
	},
	"/assets/route-bGHEzams.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2560-pz82OR4o34BsQAjHRcsEJM4vvjg\"",
		"mtime": "2026-07-09T15:34:51.158Z",
		"size": 9568,
		"path": "../public/assets/route-bGHEzams.js"
	},
	"/assets/save-Do-q-0zI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"147-T1DvmqTVhsyzJg6m2hsVepfU9qA\"",
		"mtime": "2026-07-09T15:34:51.159Z",
		"size": 327,
		"path": "../public/assets/save-Do-q-0zI.js"
	},
	"/assets/label-r2F2mZyM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"272-Esj8mtTu9kT3iyJFFEHMykZOLRE\"",
		"mtime": "2026-07-09T15:34:51.117Z",
		"size": 626,
		"path": "../public/assets/label-r2F2mZyM.js"
	},
	"/assets/select-CubNlq4t.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bfd0-OTCL4QWpcOgT62Cd86Vr6geCslc\"",
		"mtime": "2026-07-09T15:34:51.160Z",
		"size": 49104,
		"path": "../public/assets/select-CubNlq4t.js"
	},
	"/assets/switch-DHeDfqCL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e12-AoJUWfnSjIfDDD4Z740vV3BQBQs\"",
		"mtime": "2026-07-09T15:34:51.162Z",
		"size": 3602,
		"path": "../public/assets/switch-DHeDfqCL.js"
	},
	"/assets/styles-Wsf5kIuD.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"13120-NM2D+T83XuVkLYxrfvHaIRnl1pY\"",
		"mtime": "2026-07-09T15:34:51.180Z",
		"size": 78112,
		"path": "../public/assets/styles-Wsf5kIuD.css"
	},
	"/assets/roll-prestadora._id-DMMaM7wK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19a5-Qfw2Cn3pDhvUa2OSUpGnQ4RVVOI\"",
		"mtime": "2026-07-09T15:34:51.156Z",
		"size": 6565,
		"path": "../public/assets/roll-prestadora._id-DMMaM7wK.js"
	},
	"/assets/trash-2-D8KVMNrq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"148-HncEsmUFWK9bhpTN6ELyrxMRfmA\"",
		"mtime": "2026-07-09T15:34:51.163Z",
		"size": 328,
		"path": "../public/assets/trash-2-D8KVMNrq.js"
	},
	"/assets/useMatch-BFcMz5ZK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4cb-wPUbtWC1rsWY/r2cJCTEu3rMe3I\"",
		"mtime": "2026-07-09T15:34:51.166Z",
		"size": 1227,
		"path": "../public/assets/useMatch-BFcMz5ZK.js"
	},
	"/assets/truck-gxs4VXd5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e0-bA5xqVTjRvJc5sUbl4iFeRgGlxc\"",
		"mtime": "2026-07-09T15:34:51.164Z",
		"size": 736,
		"path": "../public/assets/truck-gxs4VXd5.js"
	},
	"/assets/useMutation-CG16fObi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8c5-Kw6Qo+8d3LrsAdpr7Hv6BkBcWiE\"",
		"mtime": "2026-07-09T15:34:51.168Z",
		"size": 2245,
		"path": "../public/assets/useMutation-CG16fObi.js"
	},
	"/assets/useQuery-jsIgwVIu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"225b-Fnd4i2gun/lxuKVL+mYjYjLZ4nc\"",
		"mtime": "2026-07-09T15:34:51.173Z",
		"size": 8795,
		"path": "../public/assets/useQuery-jsIgwVIu.js"
	},
	"/assets/useRouter-Rvnm1DNS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b2-nALXoe7Rhv1dDN2XmhXQrP2Xw4I\"",
		"mtime": "2026-07-09T15:34:51.175Z",
		"size": 690,
		"path": "../public/assets/useRouter-Rvnm1DNS.js"
	},
	"/assets/wallet-DkdjQM1w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d-T16LNvp8jEWicqG4TSdsWjN0cdo\"",
		"mtime": "2026-07-09T15:34:51.176Z",
		"size": 525,
		"path": "../public/assets/wallet-DkdjQM1w.js"
	},
	"/assets/x-DSHPaOOl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-9TrLs6zesrrKO5/Jp4+l+qQ540I\"",
		"mtime": "2026-07-09T15:34:51.178Z",
		"size": 154,
		"path": "../public/assets/x-DSHPaOOl.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_pMs39M = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_pMs39M
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };

import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { l as Search, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/filter-bar-BvU34MgO.js
var import_jsx_runtime = require_jsx_runtime();
function FilterBar({ value, onChange, onClear, children, showPeriodo = true, showBusca = true, showNumero = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-md border bg-card p-3 mb-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3",
			children: [
				showBusca && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 min-w-[220px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[11px] uppercase tracking-wider text-muted-foreground",
						children: "Buscar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "h-9 pl-8",
							placeholder: "Digite para pesquisar…",
							value: value.q ?? "",
							onChange: (e) => onChange({ q: e.target.value })
						})]
					})]
				}),
				showPeriodo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Período inicial"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "h-9 w-[150px]",
					value: value.dataInicio ?? "",
					onChange: (e) => onChange({ dataInicio: e.target.value })
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Período final"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "h-9 w-[150px]",
					value: value.dataFim ?? "",
					onChange: (e) => onChange({ dataFim: e.target.value })
				})] })] }),
				showNumero && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Nº Roll"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-9 w-[130px]",
					value: value.numero ?? "",
					onChange: (e) => onChange({ numero: e.target.value })
				})] }),
				children,
				onClear && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					className: "h-9",
					onClick: onClear,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5 mr-1" }), " Limpar"]
				})
			]
		})
	});
}
//#endregion
export { FilterBar as t };

import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { C as ClipboardList, a as TrendingUp, d as Receipt, i as TriangleAlert, m as Pencil, n as Wallet } from "../_libs/lucide-react.mjs";
import { t as FilterBar } from "./filter-bar-BvU34MgO.mjs";
import { i as firstOfMonth, n as brl, o as lastOfMonth, t as brDate } from "./format-BJqD7o0K.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as AnimatedPage } from "./animated-page-BNndFJHI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-Dl-BbrLP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Card({ label, value, icon: Icon, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border bg-card p-4 transition-smooth hover-scale hover:shadow-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-muted-foreground" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 text-2xl font-semibold tracking-tight",
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground mt-1",
				children: hint
			})
		]
	});
}
function Dashboard() {
	const [filters, setFilters] = (0, import_react.useState)({
		dataInicio: firstOfMonth(),
		dataFim: lastOfMonth()
	});
	const { data } = useQuery({
		queryKey: [
			"dashboard",
			filters.dataInicio,
			filters.dataFim
		],
		queryFn: async () => {
			const start = filters.dataInicio;
			const end = filters.dataFim;
			const [rolls, ultimas, divergs] = await Promise.all([
				supabase.from("rolls_alyani").select("id, total_receita, total_custo, total_lucro, data_roll").gte("data_roll", start).lte("data_roll", end),
				supabase.from("rolls_alyani").select("id, numero, data_roll, total_receita, hoteis(nome), prestadoras(nome)").order("created_at", { ascending: false }).limit(8),
				supabase.from("conferencias").select("id, total_divergencias, created_at, rolls_alyani(numero, hoteis(nome))").gt("total_divergencias", 0).order("created_at", { ascending: false }).limit(8)
			]);
			return {
				rolls: rolls.data ?? [],
				ultimas: ultimas.data ?? [],
				divergs: divergs.data ?? []
			};
		}
	});
	const totals = (0, import_react.useMemo)(() => {
		const r = data?.rolls ?? [];
		return {
			qtd: r.length,
			receita: r.reduce((s, x) => s + Number(x.total_receita ?? 0), 0),
			custo: r.reduce((s, x) => s + Number(x.total_custo ?? 0), 0),
			lucro: r.reduce((s, x) => s + Number(x.total_lucro ?? 0), 0)
		};
	}, [data]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AnimatedPage, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Dashboard",
			description: "Visão geral do período selecionado."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {
			value: filters,
			onChange: (p) => setFilters((f) => ({
				...f,
				...p
			})),
			showBusca: false,
			onClear: () => setFilters({
				dataInicio: void 0,
				dataFim: void 0
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 md:grid-cols-4 gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					label: "Rolls",
					value: String(totals.qtd),
					icon: ClipboardList
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					label: "Faturamento",
					value: brl(totals.receita),
					icon: Receipt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					label: "Pagamentos",
					value: brl(totals.custo),
					icon: Wallet
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					label: "Lucro",
					value: brl(totals.lucro),
					icon: TrendingUp
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 lg:grid-cols-2 gap-4 mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md border bg-card card-hover",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 py-3 border-b flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: "Últimas movimentações"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Roll"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Hotel"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Data"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium",
								children: "Valor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-10" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [(data?.ultimas ?? []).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 font-mono",
								children: u.numero
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2",
								children: u.hoteis?.nome ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2",
								children: brDate(u.data_roll)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-right",
								children: brl(u.total_receita)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-1 py-1 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "ghost",
									size: "icon",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/operacao/roll-alyani/$id",
										params: { id: u.id },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
									})
								})
							})
						]
					}, u.id)), (data?.ultimas ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 5,
						className: "px-4 py-6 text-center text-muted-foreground",
						children: "Sem lançamentos ainda."
					}) })] })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md border bg-card card-hover",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 py-3 border-b flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-4 w-4 text-warning" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: "Últimas divergências"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Roll Alyani"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Hotel"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium",
								children: "Divergências"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [(data?.divergs ?? []).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 font-mono",
								children: d.rolls_alyani?.numero ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2",
								children: d.rolls_alyani?.hoteis?.nome ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-right font-semibold text-destructive",
								children: d.total_divergencias
							})
						]
					}, d.id)), (data?.divergs ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 3,
						className: "px-4 py-6 text-center text-muted-foreground",
						children: "Sem divergências no período."
					}) })] })]
				})]
			})]
		})
	] });
}
//#endregion
export { Dashboard as component };

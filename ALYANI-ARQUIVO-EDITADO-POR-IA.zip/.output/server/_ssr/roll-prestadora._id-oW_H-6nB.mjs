import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { k as ArrowLeft, o as Trash2, p as Plus, u as Save } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Route } from "./roll-prestadora._id-KYSFFPc2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/roll-prestadora._id-oW_H-6nB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { id } = Route.useParams();
	const qc = useQueryClient();
	useNavigate();
	const { data: roll, refetch } = useQuery({
		queryKey: ["roll-prestadora", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("rolls_prestadora").select("*, prestadoras(nome)").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const { data: itens = [], refetch: refetchItens } = useQuery({
		queryKey: ["roll-prestadora-itens", id],
		queryFn: async () => (await supabase.from("rolls_prestadora_itens").select("*, pecas(nome)").eq("roll_id", id).order("created_at")).data ?? []
	});
	const { data: pecas = [] } = useQuery({
		queryKey: ["pecas-lite"],
		queryFn: async () => (await supabase.from("pecas").select("id,nome").eq("status", "ativo").order("nome")).data ?? []
	});
	const { data: prestadoras = [] } = useQuery({
		queryKey: ["prestadoras-lite"],
		queryFn: async () => (await supabase.from("prestadoras").select("id,nome").eq("status", "ativo").order("nome")).data ?? []
	});
	const [header, setHeader] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (roll) setHeader(roll);
	}, [roll]);
	const saveHeader = useMutation({
		mutationFn: async () => {
			const payload = {
				numero: header.numero,
				data_roll: header.data_roll,
				prestadora_id: header.prestadora_id
			};
			const { error } = await supabase.from("rolls_prestadora").update(payload).eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Roll atualizado.");
			qc.invalidateQueries({ queryKey: ["roll-prestadora", id] });
			qc.invalidateQueries({ queryKey: ["rolls_prestadora"] });
		},
		onError: (e) => toast.error(e.message)
	});
	const upsertItem = useMutation({
		mutationFn: async (it) => {
			if (it.id) {
				const { error } = await supabase.from("rolls_prestadora_itens").update({
					peca_id: it.peca_id,
					quantidade: it.quantidade
				}).eq("id", it.id);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("rolls_prestadora_itens").insert({
					roll_id: id,
					peca_id: it.peca_id,
					quantidade: it.quantidade
				});
				if (error) throw error;
			}
		},
		onSuccess: () => {
			refetchItens();
			refetch();
		},
		onError: (e) => toast.error(e.message)
	});
	const removeItem = useMutation({
		mutationFn: async (iid) => {
			const { error } = await supabase.from("rolls_prestadora_itens").delete().eq("id", iid);
			if (error) throw error;
		},
		onSuccess: () => {
			refetchItens();
			refetch();
		},
		onError: (e) => toast.error(e.message)
	});
	const [novoItem, setNovoItem] = (0, import_react.useState)({
		peca_id: "",
		quantidade: 1
	});
	const totals = (0, import_react.useMemo)(() => {
		return { qtd: itens.reduce((s, x) => s + Number(x.quantidade ?? 0), 0) };
	}, [itens]);
	if (!header) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: `Roll #${header.numero}`,
			description: header.prestadoras?.nome ?? "",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/operacao/roll-prestadora",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4 mr-1" }), " Voltar"]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => saveHeader.mutate(),
				disabled: saveHeader.isPending,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-1" }), " Salvar cabeçalho"]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card p-4 grid grid-cols-2 md:grid-cols-4 gap-3 mb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nº do Roll" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: header.numero ?? "",
					onChange: (e) => setHeader({
						...header,
						numero: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Data do Roll" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					value: header.data_roll ?? "",
					onChange: (e) => setHeader({
						...header,
						data_roll: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Prestadora" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: header.prestadora_id ?? "",
						onValueChange: (v) => setHeader({
							...header,
							prestadora_id: v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "—" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: prestadoras.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: p.id,
							children: p.nome
						}, p.id)) })]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 py-3 border-b flex items-center justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: "Itens do Roll"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Peça"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium w-32",
								children: "Qtd"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-10" })
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [itens.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemRow, {
						it: i,
						pecas,
						onSave: (itm) => upsertItem.mutate({
							...itm,
							id: i.id
						}),
						onRemove: () => removeItem.mutate(i.id)
					}, i.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t bg-muted/20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: novoItem.peca_id,
									onValueChange: (v) => setNovoItem({
										...novoItem,
										peca_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-8",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione a peça…" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: pecas.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: p.id,
										children: p.nome
									}, p.id)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "h-8 text-right font-mono",
									type: "number",
									min: 0,
									step: "1",
									value: novoItem.quantidade,
									onChange: (e) => setNovoItem({
										...novoItem,
										quantidade: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									disabled: !novoItem.peca_id || novoItem.quantidade <= 0,
									onClick: () => {
										upsertItem.mutate(novoItem);
										setNovoItem({
											peca_id: "",
											quantidade: 1
										});
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
								})
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
						className: "bg-muted/30 font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-xs uppercase tracking-wider text-muted-foreground",
								children: "Total de peças"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-right font-mono",
								children: totals.qtd
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {})
						] })
					})
				]
			})]
		})
	] });
}
function ItemRow({ it, pecas, onSave, onRemove }) {
	const [local, setLocal] = (0, import_react.useState)({
		id: it.id,
		peca_id: it.peca_id,
		quantidade: Number(it.quantidade)
	});
	const dirty = local.peca_id !== it.peca_id || local.quantidade !== Number(it.quantidade);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: local.peca_id,
					onValueChange: (v) => setLocal({
						...local,
						peca_id: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: pecas.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: p.id,
						children: p.nome
					}, p.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-8 text-right font-mono",
					type: "number",
					min: 0,
					value: local.quantidade,
					onChange: (e) => setLocal({
						...local,
						quantidade: Number(e.target.value)
					}),
					onBlur: () => dirty && onSave(local)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-1 py-1 text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					onClick: onRemove,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4 text-destructive" })
				})
			})
		]
	});
}
//#endregion
export { Page as component };

import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { u as Save } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/conferencia-B9bdMRy5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const qc = useQueryClient();
	const [rollAlyaniId, setRollAlyaniId] = (0, import_react.useState)("");
	const [rollPrestadoraId, setRollPrestadoraId] = (0, import_react.useState)("");
	const { data: rollsAlyani = [] } = useQuery({
		queryKey: ["rolls_alyani_all"],
		queryFn: async () => (await supabase.from("rolls_alyani").select("id,numero,data_roll,hoteis(nome),prestadora_id").order("data_roll", { ascending: false }).limit(300)).data ?? []
	});
	const { data: rollsPrest = [] } = useQuery({
		queryKey: ["rolls_prestadora_all"],
		queryFn: async () => (await supabase.from("rolls_prestadora").select("id,numero,data_roll,prestadora_id,prestadoras(nome)").order("data_roll", { ascending: false }).limit(300)).data ?? []
	});
	const { data: itensAlyani = [] } = useQuery({
		queryKey: ["conf-ra", rollAlyaniId],
		enabled: !!rollAlyaniId,
		queryFn: async () => (await supabase.from("rolls_alyani_itens").select("peca_id, quantidade, pecas(nome)").eq("roll_id", rollAlyaniId)).data ?? []
	});
	const { data: itensPrest = [] } = useQuery({
		queryKey: ["conf-rp", rollPrestadoraId],
		enabled: !!rollPrestadoraId,
		queryFn: async () => (await supabase.from("rolls_prestadora_itens").select("peca_id, quantidade, pecas(nome)").eq("roll_id", rollPrestadoraId)).data ?? []
	});
	const linhas = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const i of itensAlyani) map.set(i.peca_id, {
			peca_id: i.peca_id,
			nome: i.pecas?.nome ?? "—",
			qtd_alyani: Number(i.quantidade),
			qtd_prest: 0
		});
		for (const i of itensPrest) {
			const cur = map.get(i.peca_id);
			if (cur) cur.qtd_prest = Number(i.quantidade);
			else map.set(i.peca_id, {
				peca_id: i.peca_id,
				nome: i.pecas?.nome ?? "—",
				qtd_alyani: 0,
				qtd_prest: Number(i.quantidade)
			});
		}
		return [...map.values()].sort((a, b) => a.nome.localeCompare(b.nome));
	}, [itensAlyani, itensPrest]);
	const totalDiv = linhas.reduce((s, l) => s + (l.qtd_alyani !== l.qtd_prest ? 1 : 0), 0);
	const save = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("conferencias").upsert({
				roll_alyani_id: rollAlyaniId,
				roll_prestadora_id: rollPrestadoraId,
				total_divergencias: totalDiv
			}, { onConflict: "roll_alyani_id,roll_prestadora_id" });
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Conferência salva.");
			qc.invalidateQueries({ queryKey: ["dashboard"] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Conferência",
			description: "Comparar Roll Alyani × Roll Prestadora.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				disabled: !rollAlyaniId || !rollPrestadoraId || save.isPending,
				onClick: () => save.mutate(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-1" }), " Salvar conferência"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card p-3 mb-4 grid md:grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: "Roll Alyani"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: rollAlyaniId,
				onValueChange: setRollAlyaniId,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-9",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione…" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: rollsAlyani.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
					value: r.id,
					children: [
						r.numero,
						" — ",
						r.hoteis?.nome
					]
				}, r.id)) })]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: "Roll Prestadora"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: rollPrestadoraId,
				onValueChange: setRollPrestadoraId,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-9",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione…" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: rollsPrest.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
					value: r.id,
					children: [
						r.numero,
						" — ",
						r.prestadoras?.nome
					]
				}, r.id)) })]
			})] })]
		}),
		!rollAlyaniId || !rollPrestadoraId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border rounded-md p-10 text-center text-muted-foreground bg-card text-sm",
			children: "Selecione os dois rolls para conferir."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 py-3 border-b flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: "Comparativo por peça"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `text-sm ${totalDiv > 0 ? "text-destructive font-semibold" : "text-success font-semibold"}`,
					children: totalDiv > 0 ? `${totalDiv} divergência(s)` : "Sem divergências"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Peça"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right px-4 py-2 font-medium w-32",
							children: "Alyani"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right px-4 py-2 font-medium w-32",
							children: "Prestadora"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right px-4 py-2 font-medium w-32",
							children: "Diferença"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [linhas.map((l) => {
					const diff = l.qtd_alyani - l.qtd_prest;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-1.5",
								children: l.nome
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-1.5 text-right font-mono",
								children: l.qtd_alyani
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-1.5 text-right font-mono",
								children: l.qtd_prest
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: `px-4 py-1.5 text-right font-mono ${diff !== 0 ? "text-destructive font-semibold" : "text-muted-foreground"}`,
								children: diff > 0 ? `+${diff}` : diff
							})
						]
					}, l.peca_id);
				}), linhas.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 4,
					className: "px-4 py-8 text-center text-muted-foreground",
					children: "Sem itens nos rolls selecionados."
				}) })] })]
			})]
		})
	] });
}
//#endregion
export { Page as component };

import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { t as FilterBar } from "./filter-bar-BvU34MgO.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { i as firstOfMonth, n as brl, o as lastOfMonth, t as brDate } from "./format-BJqD7o0K.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pagamentos-D1o9BgPr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var statusColor = {
	pendente: "text-warning",
	pago: "text-success",
	cancelado: "text-muted-foreground"
};
function Page() {
	const qc = useQueryClient();
	const [filters, setFilters] = (0, import_react.useState)({
		dataInicio: firstOfMonth(),
		dataFim: lastOfMonth()
	});
	const { data: prestadoras = [] } = useQuery({
		queryKey: ["prestadoras-lite"],
		queryFn: async () => (await supabase.from("prestadoras").select("id,nome").eq("status", "ativo").order("nome")).data ?? []
	});
	const { data = [] } = useQuery({
		queryKey: ["pagamentos", filters],
		queryFn: async () => {
			let q = supabase.from("pagamentos").select("*, prestadoras(nome), rolls_alyani(numero, data_roll, hoteis(nome))").order("created_at", { ascending: false });
			if (filters.dataInicio) q = q.gte("data_pagamento", filters.dataInicio);
			if (filters.dataFim) q = q.lte("data_pagamento", filters.dataFim);
			if (filters.prestadoraId) q = q.eq("prestadora_id", filters.prestadoraId);
			if (filters.status) q = q.eq("status", filters.status);
			return (await q).data ?? [];
		}
	});
	const rows = (0, import_react.useMemo)(() => {
		const q = (filters.q ?? "").toLowerCase().trim();
		return q ? data.filter((c) => [c.rolls_alyani?.numero, c.prestadoras?.nome].some((v) => (v ?? "").toString().toLowerCase().includes(q))) : data;
	}, [data, filters.q]);
	const totals = (0, import_react.useMemo)(() => rows.reduce((a, r) => ({
		total: a.total + Number(r.valor),
		pago: a.pago + (r.status === "pago" ? Number(r.valor) : 0),
		pendente: a.pendente + (r.status === "pendente" ? Number(r.valor) : 0)
	}), {
		total: 0,
		pago: 0,
		pendente: 0
	}), [rows]);
	const patch = useMutation({
		mutationFn: async ({ id, upd }) => {
			const { error } = await supabase.from("pagamentos").update(upd).eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => qc.invalidateQueries({ queryKey: ["pagamentos"] }),
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Pagamentos",
			description: "Valores devidos às prestadoras — gerados automaticamente a partir dos Rolls Alyani."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, {
			value: filters,
			onChange: (p) => setFilters((f) => ({
				...f,
				...p
			})),
			onClear: () => setFilters({
				dataInicio: firstOfMonth(),
				dataFim: lastOfMonth()
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: "Prestadora"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: filters.prestadoraId ?? "__all",
				onValueChange: (v) => setFilters((f) => ({
					...f,
					prestadoraId: v === "__all" ? void 0 : v
				})),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-9 w-[200px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "__all",
					children: "Todas"
				}), prestadoras.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: h.id,
					children: h.nome
				}, h.id))] })]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: "Status"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: filters.status ?? "__all",
				onValueChange: (v) => setFilters((f) => ({
					...f,
					status: v === "__all" ? void 0 : v
				})),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-9 w-[140px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "__all",
						children: "Todos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "pendente",
						children: "Pendente"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "pago",
						children: "Pago"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "cancelado",
						children: "Cancelado"
					})
				] })]
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-3 mb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase text-muted-foreground",
						children: "Total"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xl font-semibold mt-1",
						children: brl(totals.total)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase text-muted-foreground",
						children: "Pendente"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xl font-semibold mt-1 text-warning",
						children: brl(totals.pendente)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase text-muted-foreground",
						children: "Pago"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xl font-semibold mt-1 text-success",
						children: brl(totals.pago)
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-md border bg-card overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Roll"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Hotel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Prestadora"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Data Roll"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right px-4 py-2 font-medium",
							children: "Valor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium w-40",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium w-40",
							children: "Pagamento"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-1.5 font-mono",
							children: c.rolls_alyani?.numero
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-1.5 text-muted-foreground",
							children: c.rolls_alyani?.hoteis?.nome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-1.5",
							children: c.prestadoras?.nome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-1.5",
							children: brDate(c.rolls_alyani?.data_roll)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-1.5 text-right font-mono",
							children: brl(c.valor)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: c.status,
								onValueChange: (v) => patch.mutate({
									id: c.id,
									upd: {
										status: v,
										data_pagamento: v === "pago" && !c.data_pagamento ? (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) : c.data_pagamento
									}
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: `h-8 ${statusColor[c.status]}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "pendente",
										children: "Pendente"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "pago",
										children: "Pago"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "cancelado",
										children: "Cancelado"
									})
								] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								className: "h-8",
								value: c.data_pagamento ?? "",
								onChange: (e) => patch.mutate({
									id: c.id,
									upd: { data_pagamento: e.target.value || null }
								})
							})
						})
					]
				}, c.id)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 7,
					className: "px-4 py-10 text-center text-muted-foreground",
					children: "Nenhum pagamento no período."
				}) })] })]
			})
		})
	] });
}
//#endregion
export { Page as component };

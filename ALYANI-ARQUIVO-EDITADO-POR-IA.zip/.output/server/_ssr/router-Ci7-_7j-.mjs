import { t as supabase } from "./client-DgPN1DO6.mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { A as redirect, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Route$18 } from "./roll-alyani._id-DcEwlpwO.mjs";
import { t as Route$19 } from "./roll-prestadora._id-KYSFFPc2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Ci7-_7j-.js
var import_jsx_runtime = require_jsx_runtime();
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var styles_default = "/assets/styles-Wsf5kIuD.css";
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold",
					children: "Página não encontrada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "A página que você procura não existe ou foi movida."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90",
						children: "Voltar ao início"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight",
					children: "Erro ao carregar a página"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Algo deu errado. Tente novamente ou volte ao início."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90",
						children: "Tentar novamente"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border px-4 py-2 text-sm font-medium hover:bg-accent",
						children: "Início"
					})]
				})
			]
		})
	});
}
var Route$17 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Alyani Lavanderia — Sistema de Gestão" },
			{
				name: "description",
				content: "Sistema interno da Alyani Lavanderia: rolls, conferências, cobranças, pagamentos e relatórios."
			},
			{
				name: "author",
				content: "Alyani Lavanderia"
			},
			{
				property: "og:title",
				content: "Alyani Lavanderia — Sistema de Gestão"
			},
			{
				property: "og:description",
				content: "Gestão operacional e financeira da Alyani Lavanderia."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.ico",
			type: "image/x-icon"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$17.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			position: "top-right",
			richColors: true
		})]
	});
}
var $$splitComponentImporter$15 = () => import("./auth-Be97-MXI.mjs");
var Route$16 = createFileRoute("/auth")({
	head: () => ({ meta: [{ title: "Entrar — Alyani Lavanderia" }, {
		name: "description",
		content: "Acesso ao sistema interno da Alyani Lavanderia."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./route-BIYB_C5G.mjs");
var Route$15 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var Route$14 = createFileRoute("/")({ beforeLoad: () => {
	throw redirect({ to: "/dashboard" });
} });
var $$splitComponentImporter$13 = () => import("./dashboard-Dl-BbrLP.mjs");
var Route$13 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [{ title: "Dashboard — Alyani Lavanderia" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./configuracoes-DCW5wCYU.mjs");
var Route$12 = createFileRoute("/_authenticated/configuracoes")({
	head: () => ({ meta: [{ title: "Configurações — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./relatorios-DJhSzDG4.mjs");
var Route$11 = createFileRoute("/_authenticated/relatorios/")({
	head: () => ({ meta: [{ title: "Relatórios — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./precos-Ck0-WL9i.mjs");
var Route$10 = createFileRoute("/_authenticated/tabelas/precos")({
	head: () => ({ meta: [{ title: "Tabela de Preços — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./custos-B8k2Ulkt.mjs");
var Route$9 = createFileRoute("/_authenticated/tabelas/custos")({
	head: () => ({ meta: [{ title: "Tabela de Custos — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./hotel-CdspnY8J.mjs");
var Route$8 = createFileRoute("/_authenticated/relatorios/hotel")({
	head: () => ({ meta: [{ title: "Relatório por Hotel — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./roll-prestadora-DUavkwQe.mjs");
var Route$7 = createFileRoute("/_authenticated/operacao/roll-prestadora")({
	head: () => ({ meta: [{ title: "Roll Prestadora — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./roll-alyani-D2NXcqot.mjs");
var Route$6 = createFileRoute("/_authenticated/operacao/roll-alyani")({
	head: () => ({ meta: [{ title: "Roll Alyani — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./conferencia-B9bdMRy5.mjs");
var Route$5 = createFileRoute("/_authenticated/operacao/conferencia")({
	head: () => ({ meta: [{ title: "Conferência — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./pagamentos-D1o9BgPr.mjs");
var Route$4 = createFileRoute("/_authenticated/financeiro/pagamentos")({
	head: () => ({ meta: [{ title: "Pagamentos — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./cobrancas-D_4TktwM.mjs");
var Route$3 = createFileRoute("/_authenticated/financeiro/cobrancas")({
	head: () => ({ meta: [{ title: "Cobranças — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./prestadoras-CMGk6OnI.mjs");
var Route$2 = createFileRoute("/_authenticated/cadastros/prestadoras")({
	head: () => ({ meta: [{ title: "Prestadoras — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./pecas-CR_IMbUL.mjs");
var Route$1 = createFileRoute("/_authenticated/cadastros/pecas")({
	head: () => ({ meta: [{ title: "Peças — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./hoteis-CWJrVAoa.mjs");
var Route = createFileRoute("/_authenticated/cadastros/hoteis")({
	head: () => ({ meta: [{ title: "Hotéis — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var AuthRoute = Route$16.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$17
});
var AuthenticatedRouteRoute = Route$15.update({
	id: "/_authenticated",
	getParentRoute: () => Route$17
});
var IndexRoute = Route$14.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$17
});
var AuthenticatedDashboardRoute = Route$13.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedConfiguracoesRoute = Route$12.update({
	id: "/configuracoes",
	path: "/configuracoes",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRelatoriosIndexRoute = Route$11.update({
	id: "/relatorios/",
	path: "/relatorios/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTabelasPrecosRoute = Route$10.update({
	id: "/tabelas/precos",
	path: "/tabelas/precos",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTabelasCustosRoute = Route$9.update({
	id: "/tabelas/custos",
	path: "/tabelas/custos",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRelatoriosHotelRoute = Route$8.update({
	id: "/relatorios/hotel",
	path: "/relatorios/hotel",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedOperacaoRollPrestadoraRoute = Route$7.update({
	id: "/operacao/roll-prestadora",
	path: "/operacao/roll-prestadora",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedOperacaoRollAlyaniRoute = Route$6.update({
	id: "/operacao/roll-alyani",
	path: "/operacao/roll-alyani",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedOperacaoConferenciaRoute = Route$5.update({
	id: "/operacao/conferencia",
	path: "/operacao/conferencia",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedFinanceiroPagamentosRoute = Route$4.update({
	id: "/financeiro/pagamentos",
	path: "/financeiro/pagamentos",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedFinanceiroCobrancasRoute = Route$3.update({
	id: "/financeiro/cobrancas",
	path: "/financeiro/cobrancas",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCadastrosPrestadorasRoute = Route$2.update({
	id: "/cadastros/prestadoras",
	path: "/cadastros/prestadoras",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCadastrosPecasRoute = Route$1.update({
	id: "/cadastros/pecas",
	path: "/cadastros/pecas",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCadastrosHoteisRoute = Route.update({
	id: "/cadastros/hoteis",
	path: "/cadastros/hoteis",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedOperacaoRollPrestadoraIdRoute = Route$19.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AuthenticatedOperacaoRollPrestadoraRoute
});
var AuthenticatedOperacaoRollAlyaniRouteChildren = { AuthenticatedOperacaoRollAlyaniIdRoute: Route$18.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AuthenticatedOperacaoRollAlyaniRoute
}) };
var AuthenticatedOperacaoRollAlyaniRouteWithChildren = AuthenticatedOperacaoRollAlyaniRoute._addFileChildren(AuthenticatedOperacaoRollAlyaniRouteChildren);
var AuthenticatedOperacaoRollPrestadoraRouteChildren = { AuthenticatedOperacaoRollPrestadoraIdRoute };
var AuthenticatedRouteRouteChildren = {
	AuthenticatedConfiguracoesRoute,
	AuthenticatedDashboardRoute,
	AuthenticatedCadastrosHoteisRoute,
	AuthenticatedCadastrosPecasRoute,
	AuthenticatedCadastrosPrestadorasRoute,
	AuthenticatedFinanceiroCobrancasRoute,
	AuthenticatedFinanceiroPagamentosRoute,
	AuthenticatedOperacaoConferenciaRoute,
	AuthenticatedOperacaoRollAlyaniRoute: AuthenticatedOperacaoRollAlyaniRouteWithChildren,
	AuthenticatedOperacaoRollPrestadoraRoute: AuthenticatedOperacaoRollPrestadoraRoute._addFileChildren(AuthenticatedOperacaoRollPrestadoraRouteChildren),
	AuthenticatedRelatoriosHotelRoute,
	AuthenticatedTabelasCustosRoute,
	AuthenticatedTabelasPrecosRoute,
	AuthenticatedRelatoriosIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AuthRoute
};
var routeTree = Route$17._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };

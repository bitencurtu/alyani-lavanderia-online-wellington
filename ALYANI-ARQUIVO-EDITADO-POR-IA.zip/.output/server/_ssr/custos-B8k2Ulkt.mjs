import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { u as Save } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { a as isoDate, r as brlNumber } from "./format-BJqD7o0K.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/custos-B8k2Ulkt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const qc = useQueryClient();
	const [prestadoraId, setPrestadoraId] = (0, import_react.useState)("");
	const [vigencia, setVigencia] = (0, import_react.useState)(isoDate());
	const { data: prestadorasData } = useQuery({
		queryKey: ["prestadoras-lite"],
		queryFn: async () => {
			const { data } = await supabase.from("prestadoras").select("id,nome").eq("status", "ativo").order("nome");
			return data ?? [];
		}
	});
	const { data: pecasData } = useQuery({
		queryKey: ["pecas-lite"],
		queryFn: async () => {
			const { data } = await supabase.from("pecas").select("id,nome").eq("status", "ativo").order("nome");
			return data ?? [];
		}
	});
	const { data: custosData } = useQuery({
		queryKey: ["custos", prestadoraId],
		enabled: !!prestadoraId,
		queryFn: async () => {
			const { data } = await supabase.from("tabela_custos").select("*").eq("prestadora_id", prestadoraId).order("data_vigencia", { ascending: false });
			return data ?? [];
		}
	});
	const prestadoras = (0, import_react.useMemo)(() => prestadorasData ?? [], [prestadorasData]);
	const pecas = (0, import_react.useMemo)(() => pecasData ?? [], [pecasData]);
	const custos = (0, import_react.useMemo)(() => custosData ?? [], [custosData]);
	const [rows, setRows] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!pecas.length) return;
		const latest = /* @__PURE__ */ new Map();
		for (const p of custos) {
			if (p.data_vigencia > vigencia) continue;
			if (!latest.has(p.peca_id)) latest.set(p.peca_id, p);
		}
		const exact = /* @__PURE__ */ new Map();
		for (const p of custos) if (p.data_vigencia === vigencia) exact.set(p.peca_id, p);
		setRows(pecas.map((pc) => {
			const src = exact.get(pc.id) ?? latest.get(pc.id);
			return {
				peca_id: pc.id,
				nome: pc.nome,
				valor: Number(src?.valor ?? 0),
				existing_id: exact.get(pc.id)?.id
			};
		}));
	}, [
		pecas,
		custos,
		vigencia
	]);
	const save = useMutation({
		mutationFn: async () => {
			const payload = rows.map((r) => {
				const item = {
					prestadora_id: prestadoraId,
					peca_id: r.peca_id,
					valor: r.valor,
					data_vigencia: vigencia,
					status: "ativo"
				};
				if (r.existing_id) item.id = r.existing_id;
				return item;
			});
			const { error } = await supabase.from("tabela_custos").upsert(payload, { onConflict: "prestadora_id,peca_id,data_vigencia" });
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Custos salvos.");
			qc.invalidateQueries({ queryKey: ["custos", prestadoraId] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Tabela de Custos",
			description: "Valores pagos às prestadoras por peça.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				disabled: !prestadoraId || save.isPending,
				onClick: () => save.mutate(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-1" }), " Salvar vigência"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card p-3 mb-4 flex flex-wrap items-end gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-[260px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Prestadora"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: prestadoraId,
					onValueChange: setPrestadoraId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-9",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione…" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: prestadoras.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: h.id,
						children: h.nome
					}, h.id)) })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: "Data de vigência"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "date",
				className: "h-9 w-[160px]",
				value: vigencia,
				onChange: (e) => setVigencia(e.target.value)
			})] })]
		}),
		!prestadoraId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border rounded-md p-10 text-center text-muted-foreground bg-card text-sm",
			children: "Selecione uma prestadora para editar os custos."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-md border bg-card overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Peça"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right px-4 py-2 font-medium w-40",
							children: "Custo unitário"
						})] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-1.5",
							children: r.nome
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								min: 0,
								className: "h-8 text-right font-mono",
								value: r.valor,
								onChange: (e) => setRows((rs) => rs.map((x, i) => i === idx ? {
									...x,
									valor: Number(e.target.value)
								} : x))
							})
						})]
					}, r.peca_id)) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
						className: "bg-muted/30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-2 text-xs text-muted-foreground",
							children: ["Total de peças: ", rows.length]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-4 py-2 text-right font-mono text-xs",
							children: ["Σ ", brlNumber(rows.reduce((s, r) => s + r.valor, 0))]
						})] })
					})
				]
			})
		})
	] });
}
//#endregion
export { Page as component };

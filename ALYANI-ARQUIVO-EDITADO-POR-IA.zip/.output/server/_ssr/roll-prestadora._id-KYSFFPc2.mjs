import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/roll-prestadora._id-KYSFFPc2.js
var $$splitComponentImporter = () => import("./roll-prestadora._id-oW_H-6nB.mjs");
var Route = createFileRoute("/_authenticated/operacao/roll-prestadora/$id")({
	head: () => ({ meta: [{ title: "Roll Prestadora — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { u as Save } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { a as isoDate, r as brlNumber } from "./format-BJqD7o0K.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/precos-Ck0-WL9i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const qc = useQueryClient();
	const [hotelId, setHotelId] = (0, import_react.useState)("");
	const [vigencia, setVigencia] = (0, import_react.useState)(isoDate());
	const { data: hoteisData } = useQuery({
		queryKey: ["hoteis-lite"],
		queryFn: async () => {
			const { data } = await supabase.from("hoteis").select("id,nome").eq("status", "ativo").order("nome");
			return data ?? [];
		}
	});
	const { data: pecasData } = useQuery({
		queryKey: ["pecas-lite"],
		queryFn: async () => {
			const { data } = await supabase.from("pecas").select("id,nome").eq("status", "ativo").order("nome");
			return data ?? [];
		}
	});
	const { data: precosData } = useQuery({
		queryKey: ["precos", hotelId],
		enabled: !!hotelId,
		queryFn: async () => {
			const { data } = await supabase.from("tabela_precos").select("*").eq("hotel_id", hotelId).order("data_vigencia", { ascending: false });
			return data ?? [];
		}
	});
	const hoteis = (0, import_react.useMemo)(() => hoteisData ?? [], [hoteisData]);
	const pecas = (0, import_react.useMemo)(() => pecasData ?? [], [pecasData]);
	const precos = (0, import_react.useMemo)(() => precosData ?? [], [precosData]);
	const [rows, setRows] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!pecas.length) return;
		const latest = /* @__PURE__ */ new Map();
		for (const p of precos) {
			if (p.data_vigencia > vigencia) continue;
			if (!latest.has(p.peca_id)) latest.set(p.peca_id, p);
		}
		const exact = /* @__PURE__ */ new Map();
		for (const p of precos) if (p.data_vigencia === vigencia) exact.set(p.peca_id, p);
		setRows(pecas.map((pc) => {
			const src = exact.get(pc.id) ?? latest.get(pc.id);
			return {
				peca_id: pc.id,
				nome: pc.nome,
				valor_normal: Number(src?.valor_normal ?? 0),
				valor_expresso: Number(src?.valor_expresso ?? 0),
				existing_id: exact.get(pc.id)?.id
			};
		}));
	}, [
		pecas,
		precos,
		vigencia
	]);
	const save = useMutation({
		mutationFn: async () => {
			const payload = rows.map((r) => {
				const item = {
					hotel_id: hotelId,
					peca_id: r.peca_id,
					valor_normal: r.valor_normal,
					valor_expresso: r.valor_expresso,
					data_vigencia: vigencia,
					status: "ativo"
				};
				if (r.existing_id) item.id = r.existing_id;
				return item;
			});
			const { error } = await supabase.from("tabela_precos").upsert(payload, { onConflict: "hotel_id,peca_id,data_vigencia" });
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Preços salvos.");
			qc.invalidateQueries({ queryKey: ["precos", hotelId] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Tabela de Preços",
			description: "Preços por hotel. O sistema usa a vigência mais recente até a data do roll.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				disabled: !hotelId || save.isPending,
				onClick: () => save.mutate(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-1" }), " Salvar vigência"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card p-3 mb-4 flex flex-wrap items-end gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-[260px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Hotel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: hotelId,
					onValueChange: setHotelId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-9",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione um hotel…" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: hoteis.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: h.id,
						children: h.nome
					}, h.id)) })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: "Data de vigência"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "date",
				className: "h-9 w-[160px]",
				value: vigencia,
				onChange: (e) => setVigencia(e.target.value)
			})] })]
		}),
		!hotelId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border rounded-md p-10 text-center text-muted-foreground bg-card text-sm",
			children: "Selecione um hotel para editar os preços."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-md border bg-card overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Peça"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium w-40",
								children: "Valor normal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium w-40",
								children: "Valor expresso"
							})
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-1.5",
								children: r.nome
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									min: 0,
									className: "h-8 text-right font-mono",
									value: r.valor_normal,
									onChange: (e) => setRows((rs) => rs.map((x, i) => i === idx ? {
										...x,
										valor_normal: Number(e.target.value)
									} : x))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									min: 0,
									className: "h-8 text-right font-mono",
									value: r.valor_expresso,
									onChange: (e) => setRows((rs) => rs.map((x, i) => i === idx ? {
										...x,
										valor_expresso: Number(e.target.value)
									} : x))
								})
							})
						]
					}, r.peca_id)) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
						className: "bg-muted/30",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-2 text-xs text-muted-foreground",
								children: ["Total de peças: ", rows.length]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-2 text-right font-mono text-xs",
								children: ["Σ ", brlNumber(rows.reduce((s, r) => s + r.valor_normal, 0))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-2 text-right font-mono text-xs",
								children: ["Σ ", brlNumber(rows.reduce((s, r) => s + r.valor_expresso, 0))]
							})
						] })
					})
				]
			})
		})
	] });
}
//#endregion
export { Page as component };

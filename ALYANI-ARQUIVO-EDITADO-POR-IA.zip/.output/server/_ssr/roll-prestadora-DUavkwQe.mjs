import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { m as Pencil, o as Trash2, p as Plus } from "../_libs/lucide-react.mjs";
import { t as FilterBar } from "./filter-bar-BvU34MgO.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { a as isoDate, i as firstOfMonth, o as lastOfMonth, t as brDate } from "./format-BJqD7o0K.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as AnimatedPage } from "./animated-page-BNndFJHI.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-D5oIT09m.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/roll-prestadora-DUavkwQe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const [filters, setFilters] = (0, import_react.useState)({
		dataInicio: firstOfMonth(),
		dataFim: lastOfMonth()
	});
	const [open, setOpen] = (0, import_react.useState)(false);
	const [novo, setNovo] = (0, import_react.useState)({
		prestadora_id: "",
		numero: "",
		data_roll: isoDate()
	});
	const [novoItens, setNovoItens] = (0, import_react.useState)([]);
	const { data: prestadoras = [] } = useQuery({
		queryKey: ["prestadoras-lite"],
		queryFn: async () => (await supabase.from("prestadoras").select("id,nome").eq("status", "ativo").order("nome")).data ?? []
	});
	const { data: pecas = [] } = useQuery({
		queryKey: ["pecas-lite"],
		queryFn: async () => (await supabase.from("pecas").select("id,nome").eq("status", "ativo").order("nome")).data ?? []
	});
	const { data: rolls = [] } = useQuery({
		queryKey: ["rolls_prestadora", filters],
		queryFn: async () => {
			let q = supabase.from("rolls_prestadora").select("id, numero, data_roll, prestadoras(nome)").order("data_roll", { ascending: false });
			if (filters.dataInicio) q = q.gte("data_roll", filters.dataInicio);
			if (filters.dataFim) q = q.lte("data_roll", filters.dataFim);
			if (filters.prestadoraId) q = q.eq("prestadora_id", filters.prestadoraId);
			if (filters.numero) q = q.ilike("numero", `%${filters.numero}%`);
			const { data, error } = await q;
			if (error) throw error;
			return data ?? [];
		}
	});
	const create = useMutation({
		mutationFn: async () => {
			const { data: rollData, error: rollError } = await supabase.from("rolls_prestadora").insert(novo).select("id").single();
			if (rollError) throw rollError;
			if (novoItens.length > 0) {
				const itemsPayload = novoItens.map((item) => ({
					roll_id: rollData.id,
					peca_id: item.peca_id,
					quantidade: item.quantidade
				}));
				const { error: itemsError } = await supabase.from("rolls_prestadora_itens").insert(itemsPayload);
				if (itemsError) throw itemsError;
			}
			return rollData.id;
		},
		onSuccess: (id) => {
			toast.success("Roll criado.");
			qc.invalidateQueries({ queryKey: ["rolls_prestadora"] });
			setOpen(false);
			setNovoItens([]);
			navigate({
				to: "/operacao/roll-prestadora/$id",
				params: { id }
			});
		},
		onError: (e) => toast.error(e.message)
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("rolls_prestadora").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Roll excluído.");
			qc.invalidateQueries({ queryKey: ["rolls_prestadora"] });
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AnimatedPage, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Roll Prestadora",
			description: "Contagem de peças devolvida pela prestadora, usada na conferência.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 mr-1" }), " Novo Roll"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {
			value: filters,
			onChange: (p) => setFilters((f) => ({
				...f,
				...p
			})),
			showNumero: true,
			onClear: () => setFilters({
				dataInicio: void 0,
				dataFim: void 0,
				prestadoraId: void 0,
				numero: void 0
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: "Prestadora"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: filters.prestadoraId ?? "__all",
				onValueChange: (v) => setFilters((f) => ({
					...f,
					prestadoraId: v === "__all" ? void 0 : v
				})),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-9 w-[180px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Todas" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "__all",
					children: "Todas"
				}), prestadoras.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: h.id,
					children: h.nome
				}, h.id))] })]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-md border bg-card overflow-hidden card-hover",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Nº"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Data"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Prestadora"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-16" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rolls.map((r, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t hover:bg-muted/30",
					style: { animationDelay: `${index * 30}ms` },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2 font-mono",
							children: r.numero
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2",
							children: brDate(r.data_roll)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2 text-muted-foreground",
							children: r.prestadoras?.nome ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "px-1 py-1 text-right whitespace-nowrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "icon",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/operacao/roll-prestadora/$id",
									params: { id: r.id },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: () => {
									if (confirm("Excluir este Roll?")) remove.mutate(r.id);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4 text-destructive" })
							})]
						})
					]
				}, r.id)), rolls.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 4,
					className: "px-4 py-10 text-center text-muted-foreground",
					children: "Nenhum roll no período."
				}) })] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: (newOpen) => {
				setOpen(newOpen);
				if (!newOpen) setNovoItens([]);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-3xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Novo Roll Prestadora" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (e) => {
						e.preventDefault();
						create.mutate();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3 mb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Prestadora" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: novo.prestadora_id,
										onValueChange: (v) => setNovo({
											...novo,
											prestadora_id: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione…" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: prestadoras.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: h.id,
											children: h.nome
										}, h.id)) })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Número" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: novo.numero,
									onChange: (e) => setNovo({
										...novo,
										numero: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Data do Roll" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									required: true,
									value: novo.data_roll,
									onChange: (e) => setNovo({
										...novo,
										data_roll: e.target.value
									})
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border bg-card overflow-hidden mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "px-4 py-3 border-b flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Itens do Roll"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									size: "sm",
									onClick: () => setNovoItens([...novoItens, {
										peca_id: "",
										quantidade: 1
									}]),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 mr-1" }), " Adicionar Item"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "text-left px-4 py-2 font-medium",
											children: "Peça"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "text-right px-4 py-2 font-medium w-28",
											children: "Qtd"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-10" })
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [novoItens.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
												value: item.peca_id,
												onValueChange: (v) => setNovoItens(novoItens.map((it, i) => i === idx ? {
													...it,
													peca_id: v
												} : it)),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
													className: "h-8",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione…" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: pecas.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: p.id,
													children: p.nome
												}, p.id)) })]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												className: "h-8 text-right font-mono",
												type: "number",
												min: 0,
												step: "1",
												value: item.quantidade,
												onChange: (e) => setNovoItens(novoItens.map((it, i) => i === idx ? {
													...it,
													quantidade: Number(e.target.value)
												} : it))
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-1 py-1 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: "ghost",
												size: "icon",
												onClick: () => setNovoItens(novoItens.filter((_, i) => i !== idx)),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4 text-destructive" })
											})
										})
									]
								}, idx)), novoItens.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 3,
									className: "px-4 py-8 text-center text-muted-foreground",
									children: "Nenhum item adicionado"
								}) })] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setOpen(false),
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: !novo.prestadora_id || !novo.numero || create.isPending,
							children: "Criar Roll"
						})] })
					]
				})]
			})
		})
	] });
}
//#endregion
export { Page as component };

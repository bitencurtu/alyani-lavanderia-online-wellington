//#region node_modules/.nitro/vite/services/ssr/assets/format-BJqD7o0K.js
var brl = (v) => {
	const n = typeof v === "string" ? parseFloat(v) : v ?? 0;
	return (Number.isFinite(n) ? n : 0).toLocaleString("pt-BR", {
		style: "currency",
		currency: "BRL"
	});
};
var brlNumber = (v) => {
	const n = typeof v === "string" ? parseFloat(v) : v ?? 0;
	return (Number.isFinite(n) ? n : 0).toLocaleString("pt-BR", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
};
var brDate = (v) => {
	if (!v) return "";
	const d = typeof v === "string" ? /* @__PURE__ */ new Date(v + (v.length === 10 ? "T00:00:00" : "")) : v;
	if (Number.isNaN(d.getTime())) return "";
	return d.toLocaleDateString("pt-BR");
};
var isoDate = (d = /* @__PURE__ */ new Date()) => d.toISOString().slice(0, 10);
var firstOfMonth = () => {
	const d = /* @__PURE__ */ new Date();
	return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
};
var lastOfMonth = () => {
	const d = /* @__PURE__ */ new Date();
	return new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().slice(0, 10);
};
//#endregion
export { isoDate as a, firstOfMonth as i, brl as n, lastOfMonth as o, brlNumber as r, brDate as t };

import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { f as Printer } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { i as firstOfMonth, n as brl, o as lastOfMonth, r as brlNumber, t as brDate } from "./format-BJqD7o0K.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hotel-CdspnY8J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [hotelId, setHotelId] = (0, import_react.useState)("");
	const [dataInicio, setDataInicio] = (0, import_react.useState)(firstOfMonth());
	const [dataFim, setDataFim] = (0, import_react.useState)(lastOfMonth());
	const { data: hoteis = [] } = useQuery({
		queryKey: ["hoteis-lite"],
		queryFn: async () => (await supabase.from("hoteis").select("*").eq("status", "ativo").order("nome")).data ?? []
	});
	const { data: rolls = [] } = useQuery({
		queryKey: [
			"rel-hotel",
			hotelId,
			dataInicio,
			dataFim
		],
		enabled: !!hotelId,
		queryFn: async () => {
			const { data } = await supabase.from("rolls_alyani").select("id, numero, data_roll, data_vencimento, nf_fat, total_receita, rolls_alyani_itens(quantidade, valor_total, pecas(nome))").eq("hotel_id", hotelId).gte("data_roll", dataInicio).lte("data_roll", dataFim).order("data_roll");
			return data ?? [];
		}
	});
	const hotel = hoteis.find((h) => h.id === hotelId);
	const consolidado = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const r of rolls) for (const i of r.rolls_alyani_itens ?? []) {
			const nome = i.pecas?.nome ?? "—";
			const cur = map.get(nome) ?? {
				nome,
				qtd: 0,
				valor: 0
			};
			cur.qtd += Number(i.quantidade);
			cur.valor += Number(i.valor_total);
			map.set(nome, cur);
		}
		const linhas = [...map.values()].sort((a, b) => a.nome.localeCompare(b.nome));
		return {
			linhas,
			totalQtd: linhas.reduce((s, l) => s + l.qtd, 0),
			totalValor: linhas.reduce((s, l) => s + l.valor, 0)
		};
	}, [rolls]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "print:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Relatório por Hotel",
			description: "Consolidado do período no mesmo formato da planilha oficial.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => window.print(),
				disabled: !hotelId,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4 mr-1" }), " Imprimir / PDF"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card p-3 mb-4 flex flex-wrap items-end gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-[260px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-[11px] uppercase tracking-wider text-muted-foreground",
						children: "Hotel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: hotelId,
						onValueChange: setHotelId,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "h-9",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione um hotel…" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: hoteis.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: h.id,
							children: h.nome
						}, h.id)) })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Data inicial"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "h-9 w-[150px]",
					value: dataInicio,
					onChange: (e) => setDataInicio(e.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Data final"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "h-9 w-[150px]",
					value: dataFim,
					onChange: (e) => setDataFim(e.target.value)
				})] })
			]
		})]
	}), !hotelId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border rounded-md p-10 text-center text-muted-foreground bg-card text-sm",
		children: "Selecione um hotel para gerar o relatório."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "print-sheet mx-auto bg-white text-[11px] leading-tight text-black p-8 border shadow-sm",
		style: {
			width: "210mm",
			minHeight: "297mm"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b-2 border-black pb-3 mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-bold tracking-wide",
						children: "ALYANI LAVANDERIA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] uppercase tracking-widest",
						children: "Relatório de Consumo por Hotel"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right text-[10px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "uppercase text-black/60",
								children: "Período:"
							}),
							" ",
							brDate(dataInicio),
							" — ",
							brDate(dataFim)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "uppercase text-black/60",
								children: "Emissão:"
							}),
							" ",
							brDate(/* @__PURE__ */ new Date())
						] })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
					className: "w-full text-[11px] border-collapse",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "w-[110px] font-semibold uppercase text-black/70 py-0.5",
							children: "Hotel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-0.5",
							children: hotel?.nome
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "font-semibold uppercase text-black/70 py-0.5",
							children: "Razão social"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-0.5",
							children: hotel?.razao_social ?? "—"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "font-semibold uppercase text-black/70 py-0.5",
							children: "CNPJ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-0.5",
							children: hotel?.cnpj ?? "—"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "font-semibold uppercase text-black/70 py-0.5",
							children: "Endereço"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-0.5",
							children: hotel?.endereco ?? "—"
						})] })
					] })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-black text-white text-[10px] uppercase tracking-widest px-2 py-1",
					children: "Notas / Rolls do período"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse border border-black text-[11px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-black/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-left",
								children: "Nº Roll"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-left",
								children: "Data"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-left",
								children: "NF / Fatura"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-left",
								children: "Vencimento"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-right",
								children: "Valor"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rolls.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1 font-mono",
							children: r.numero
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1",
							children: brDate(r.data_roll)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1",
							children: r.nf_fat ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1",
							children: brDate(r.data_vencimento)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1 text-right font-mono",
							children: brl(r.total_receita)
						})
					] }, r.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "font-semibold bg-black/5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1",
							colSpan: 4,
							children: "TOTAL DE NOTAS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1 text-right font-mono",
							children: brl(consolidado.totalValor)
						})]
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-black text-white text-[10px] uppercase tracking-widest px-2 py-1",
					children: "Consolidado por peça"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse border border-black text-[11px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-black/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-left",
								children: "Peça"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-right w-24",
								children: "Qtd"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border border-black px-2 py-1 text-right w-32",
								children: "Valor Total"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [consolidado.linhas.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1",
							children: l.nome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1 text-right font-mono",
							children: brlNumber(l.qtd)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border border-black px-2 py-1 text-right font-mono",
							children: brl(l.valor)
						})
					] }, l.nome)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "font-semibold bg-black/5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border border-black px-2 py-1",
								children: "TOTAL"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border border-black px-2 py-1 text-right font-mono",
								children: brlNumber(consolidado.totalQtd)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border border-black px-2 py-1 text-right font-mono",
								children: brl(consolidado.totalValor)
							})
						]
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-8 pt-3 border-t border-black text-[10px] text-black/60 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Alyani Lavanderia — documento gerado pelo sistema" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Página 1 de 1" })]
			})
		]
	})] });
}
//#endregion
export { Page as component };

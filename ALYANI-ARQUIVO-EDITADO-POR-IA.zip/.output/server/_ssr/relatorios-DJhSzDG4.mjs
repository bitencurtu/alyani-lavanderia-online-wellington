import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { C as ClipboardList, O as Building2, b as FileText, f as Printer, r as Truck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/relatorios-DJhSzDG4.js
var import_jsx_runtime = require_jsx_runtime();
var items = [
	{
		to: "/relatorios/hotel",
		label: "Relatório por Hotel",
		icon: Building2,
		desc: "Consumo mensal por peça, receita e vencimentos.",
		ready: true
	},
	{
		to: "/relatorios/prestadora",
		label: "Relatório por Prestadora",
		icon: Truck,
		desc: "Peças processadas, custos e pagamentos.",
		ready: false
	},
	{
		to: "/relatorios/roll",
		label: "Espelho de Roll",
		icon: ClipboardList,
		desc: "Reprodução do Roll para envio ao cliente.",
		ready: false
	},
	{
		to: "/relatorios/faturamento",
		label: "Faturamento consolidado",
		icon: FileText,
		desc: "Totais do período por hotel e por prestadora.",
		ready: false
	}
];
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Relatórios",
		description: "Reproduzem fielmente o layout das planilhas oficiais Alyani."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-1 md:grid-cols-2 gap-3",
		children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: it.ready ? it.to : "/relatorios",
			className: `group rounded-md border bg-card p-4 flex items-start gap-3 transition ${it.ready ? "hover:border-primary" : "opacity-60 cursor-not-allowed"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-md bg-primary/10 text-primary p-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, { className: "h-5 w-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold",
							children: it.label
						}), !it.ready && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase tracking-wider text-muted-foreground border rounded px-1.5 py-0.5",
							children: "Fase 2"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground mt-1",
						children: it.desc
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition" })
			]
		}, it.to))
	})] });
}
//#endregion
export { Page as component };

import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { k as ArrowLeft, o as Trash2, p as Plus, u as Save } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { n as brl } from "./format-BJqD7o0K.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Switch } from "./switch-DIl42eeh.mjs";
import { t as Route } from "./roll-alyani._id-DcEwlpwO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/roll-alyani._id-Dqlfze8e.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { id } = Route.useParams();
	const qc = useQueryClient();
	useNavigate();
	const { data: roll, refetch } = useQuery({
		queryKey: ["roll", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("rolls_alyani").select("*, hoteis(nome), prestadoras(nome)").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const { data: itens = [], refetch: refetchItens } = useQuery({
		queryKey: ["roll-itens", id],
		queryFn: async () => {
			const { data, error } = await supabase.from("rolls_alyani_itens").select("*, pecas(nome)").eq("roll_id", id).order("created_at");
			if (error) throw error;
			return data ?? [];
		}
	});
	const { data: pecas = [] } = useQuery({
		queryKey: ["pecas-lite"],
		queryFn: async () => (await supabase.from("pecas").select("id,nome").eq("status", "ativo").order("nome")).data ?? []
	});
	const { data: prestadoras = [] } = useQuery({
		queryKey: ["prestadoras-lite"],
		queryFn: async () => (await supabase.from("prestadoras").select("id,nome").eq("status", "ativo").order("nome")).data ?? []
	});
	const [header, setHeader] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (roll) setHeader(roll);
	}, [roll]);
	const saveHeader = useMutation({
		mutationFn: async () => {
			const payload = {
				numero: header.numero,
				data_roll: header.data_roll,
				data_vencimento: header.data_vencimento,
				expresso: header.expresso,
				cobrada: header.cobrada,
				nf_fat: header.nf_fat,
				prestadora_id: header.prestadora_id,
				observacoes: header.observacoes
			};
			const { error } = await supabase.from("rolls_alyani").update(payload).eq("id", id);
			if (error) throw error;
		},
		onSuccess: async () => {
			toast.success("Roll atualizado. Itens recalculados.");
			const ids = itens.map((i) => i.id);
			for (const iid of ids) await supabase.from("rolls_alyani_itens").update({ updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", iid);
			qc.invalidateQueries({ queryKey: ["roll", id] });
			qc.invalidateQueries({ queryKey: ["roll-itens", id] });
		},
		onError: (e) => toast.error(e.message)
	});
	const upsertItem = useMutation({
		mutationFn: async (it) => {
			if (it.id) {
				const { error } = await supabase.from("rolls_alyani_itens").update({
					peca_id: it.peca_id,
					quantidade: it.quantidade,
					expresso_item: it.expresso_item
				}).eq("id", it.id);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("rolls_alyani_itens").insert({
					roll_id: id,
					peca_id: it.peca_id,
					quantidade: it.quantidade,
					expresso_item: it.expresso_item
				});
				if (error) throw error;
			}
		},
		onSuccess: () => {
			refetchItens();
			refetch();
		},
		onError: (e) => toast.error(e.message)
	});
	const removeItem = useMutation({
		mutationFn: async (iid) => {
			const { error } = await supabase.from("rolls_alyani_itens").delete().eq("id", iid);
			if (error) throw error;
		},
		onSuccess: () => {
			refetchItens();
			refetch();
		},
		onError: (e) => toast.error(e.message)
	});
	const [novoItem, setNovoItem] = (0, import_react.useState)({
		peca_id: "",
		quantidade: 1,
		expresso_item: false
	});
	const totais = (0, import_react.useMemo)(() => {
		return {
			qtd: itens.reduce((s, i) => s + Number(i.quantidade ?? 0), 0),
			receita: itens.reduce((s, i) => s + Number(i.valor_total ?? 0), 0),
			custo: itens.reduce((s, i) => s + Number(i.custo_total ?? 0), 0)
		};
	}, [itens]);
	if (!header) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: `Roll #${header.numero}`,
			description: `${header.hoteis?.nome ?? ""}${header.prestadoras?.nome ? " • " + header.prestadoras.nome : ""}`,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "ghost",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/operacao/roll-alyani",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4 mr-1" }), " Voltar"]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => saveHeader.mutate(),
				disabled: saveHeader.isPending,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-1" }), " Salvar cabeçalho"]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card p-4 grid grid-cols-2 md:grid-cols-4 gap-3 mb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nº do Roll" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: header.numero ?? "",
					onChange: (e) => setHeader({
						...header,
						numero: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Data do Roll" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					value: header.data_roll ?? "",
					onChange: (e) => setHeader({
						...header,
						data_roll: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Vencimento" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					value: header.data_vencimento ?? "",
					onChange: (e) => setHeader({
						...header,
						data_vencimento: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "NF / Fatura" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: header.nf_fat ?? "",
					onChange: (e) => setHeader({
						...header,
						nf_fat: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Prestadora" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: header.prestadora_id ?? "",
						onValueChange: (v) => setHeader({
							...header,
							prestadora_id: v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "—" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: prestadoras.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: p.id,
							children: p.nome
						}, p.id)) })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 rounded-md border p-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: !!header.expresso,
						onCheckedChange: (v) => setHeader({
							...header,
							expresso: v
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Expresso"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 rounded-md border p-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: !!header.cobrada,
						onCheckedChange: (v) => setHeader({
							...header,
							cobrada: v
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Cobrada"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md border bg-card overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 py-3 border-b flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium",
					children: "Itens do Roll"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Preços e custos vêm automaticamente das tabelas vigentes na data do roll."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-left px-4 py-2 font-medium",
								children: "Peça"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium w-24",
								children: "Qtd"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-center px-4 py-2 font-medium w-20",
								children: "Exp"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium w-28",
								children: "Vlr Unit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium w-28",
								children: "Total"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right px-4 py-2 font-medium w-28",
								children: "Custo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-10" })
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [itens.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemRow, {
						it,
						pecas,
						onSave: (u) => upsertItem.mutate({
							...u,
							id: it.id
						}),
						onRemove: () => removeItem.mutate(it.id)
					}, it.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t bg-muted/20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: novoItem.peca_id,
									onValueChange: (v) => setNovoItem({
										...novoItem,
										peca_id: v
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-8",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Selecione a peça…" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: pecas.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: p.id,
										children: p.nome
									}, p.id)) })]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "h-8 text-right font-mono",
									type: "number",
									min: 0,
									step: "1",
									value: novoItem.quantidade,
									onChange: (e) => setNovoItem({
										...novoItem,
										quantidade: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: novoItem.expresso_item,
									onCheckedChange: (v) => setNovoItem({
										...novoItem,
										expresso_item: v
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { colSpan: 3 }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-1 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									disabled: !novoItem.peca_id || novoItem.quantidade <= 0,
									onClick: () => {
										upsertItem.mutate(novoItem);
										setNovoItem({
											peca_id: "",
											quantidade: 1,
											expresso_item: false
										});
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
								})
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
						className: "bg-muted/30 font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-xs uppercase tracking-wider text-muted-foreground",
								children: "Totais"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-right font-mono",
								children: totais.qtd
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-right font-mono",
								children: brl(totais.receita)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2 text-right font-mono",
								children: brl(totais.custo)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {})
						] })
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 gap-3 mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase text-muted-foreground",
						children: "Receita"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xl font-semibold mt-1",
						children: brl(header.total_receita)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase text-muted-foreground",
						children: "Custo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xl font-semibold mt-1",
						children: brl(header.total_custo)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase text-muted-foreground",
						children: "Lucro"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xl font-semibold mt-1",
						children: brl(header.total_lucro)
					})]
				})
			]
		})
	] });
}
function ItemRow({ it, pecas, onSave, onRemove }) {
	const [local, setLocal] = (0, import_react.useState)({
		peca_id: it.peca_id,
		quantidade: Number(it.quantidade),
		expresso_item: !!it.expresso_item
	});
	const dirty = local.peca_id !== it.peca_id || local.quantidade !== Number(it.quantidade) || local.expresso_item !== !!it.expresso_item;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: local.peca_id,
					onValueChange: (v) => setLocal({
						...local,
						peca_id: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: pecas.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: p.id,
						children: p.nome
					}, p.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-8 text-right font-mono",
					type: "number",
					min: 0,
					value: local.quantidade,
					onChange: (e) => setLocal({
						...local,
						quantidade: Number(e.target.value)
					}),
					onBlur: () => dirty && onSave(local)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-1 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: local.expresso_item,
					onCheckedChange: (v) => {
						setLocal({
							...local,
							expresso_item: v
						});
						onSave({
							...local,
							expresso_item: v
						});
					}
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-1 text-right font-mono text-muted-foreground",
				children: brl(it.valor_unit)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-1 text-right font-mono",
				children: brl(it.valor_total)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-1 text-right font-mono text-muted-foreground",
				children: brl(it.custo_total)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-1 py-1 text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					onClick: onRemove,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4 text-destructive" })
				})
			})
		]
	});
}
//#endregion
export { Page as component };

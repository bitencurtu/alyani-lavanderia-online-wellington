import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/roll-alyani._id-DcEwlpwO.js
var $$splitComponentImporter = () => import("./roll-alyani._id-Dqlfze8e.mjs");
var Route = createFileRoute("/_authenticated/operacao/roll-alyani/$id")({
	head: () => ({ meta: [{ title: "Roll Alyani — Alyani" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };

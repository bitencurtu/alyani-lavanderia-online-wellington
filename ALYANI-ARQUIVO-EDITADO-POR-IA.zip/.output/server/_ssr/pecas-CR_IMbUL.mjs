import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DgPN1DO6.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./button-C1KSxKmF.mjs";
import { t as Input } from "./input-CCCvLIdb.mjs";
import { t as Label } from "./label-BhFXZmyO.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as PageHeader } from "./page-header-DhZwGdcm.mjs";
import { m as Pencil, p as Plus } from "../_libs/lucide-react.mjs";
import { t as FilterBar } from "./filter-bar-BvU34MgO.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CsgUQnBO.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./dialog-D5oIT09m.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pecas-CR_IMbUL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const qc = useQueryClient();
	const [filters, setFilters] = (0, import_react.useState)({});
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const { data = [] } = useQuery({
		queryKey: ["pecas"],
		queryFn: async () => {
			const { data, error } = await supabase.from("pecas").select("*").order("nome");
			if (error) throw error;
			return data;
		}
	});
	const rows = (0, import_react.useMemo)(() => {
		const q = (filters.q ?? "").toLowerCase().trim();
		return data.filter((p) => !q || p.nome.toLowerCase().includes(q));
	}, [data, filters.q]);
	const save = useMutation({
		mutationFn: async (h) => {
			if (h.id && h.id.trim() !== "") {
				const { error } = await supabase.from("pecas").update({
					nome: h.nome,
					status: h.status
				}).eq("id", h.id);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("pecas").insert({
					nome: h.nome,
					status: h.status
				});
				if (error) throw error;
			}
		},
		onSuccess: () => {
			toast.success("Peça salva.");
			qc.invalidateQueries({ queryKey: ["pecas"] });
			setOpen(false);
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Peças",
			description: "Catálogo de peças (roupas de cama, banho, etc).",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => {
					setEditing({
						nome: "",
						status: "ativo"
					});
					setOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 mr-1" }), " Nova peça"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterBar, {
			value: filters,
			onChange: (p) => setFilters((f) => ({
				...f,
				...p
			})),
			showPeriodo: false,
			onClear: () => setFilters({})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-md border bg-card overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-[11px] uppercase text-muted-foreground bg-muted/40",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Nome"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-left px-4 py-2 font-medium",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-10" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t hover:bg-muted/30",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2 font-medium",
							children: h.nome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: h.status === "ativo" ? "text-success text-xs font-medium" : "text-muted-foreground text-xs",
								children: h.status
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-2 py-1 text-right",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: () => {
									setEditing(h);
									setOpen(true);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
							})
						})
					]
				}, h.id)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 3,
					className: "px-4 py-8 text-center text-muted-foreground",
					children: "Nenhuma peça cadastrada."
				}) })] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: editing?.id ? "Editar peça" : "Nova peça" }) }), editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3",
				onSubmit: (e) => {
					e.preventDefault();
					save.mutate(editing);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: editing.nome,
						onChange: (e) => setEditing({
							...editing,
							nome: e.target.value
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: editing.status,
						onValueChange: (v) => setEditing({
							...editing,
							status: v
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "ativo",
							children: "Ativo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "inativo",
							children: "Inativo"
						})] })]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => setOpen(false),
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: save.isPending,
						children: "Salvar"
					})] })
				]
			})] })
		})
	] });
}
//#endregion
export { Page as component };

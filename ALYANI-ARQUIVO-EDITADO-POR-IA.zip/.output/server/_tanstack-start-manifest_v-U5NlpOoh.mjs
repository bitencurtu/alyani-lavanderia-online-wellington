//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-U5NlpOoh.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/auth"
		],
		preloads: [
			"/assets/index-DzyFWv53.js",
			"/assets/jsx-runtime-bzQ4Vb5N.js",
			"/assets/react-dom-DUKFG4MT.js",
			"/assets/link-_eKo47Xq.js",
			"/assets/useMatch-BFcMz5ZK.js",
			"/assets/useRouter-Rvnm1DNS.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DzyFWv53.js"
		} }]
	},
	"/_authenticated": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/configuracoes",
			"/_authenticated/dashboard",
			"/_authenticated/cadastros/hoteis",
			"/_authenticated/cadastros/pecas",
			"/_authenticated/cadastros/prestadoras",
			"/_authenticated/financeiro/cobrancas",
			"/_authenticated/financeiro/pagamentos",
			"/_authenticated/operacao/conferencia",
			"/_authenticated/operacao/roll-alyani",
			"/_authenticated/operacao/roll-prestadora",
			"/_authenticated/relatorios/hotel",
			"/_authenticated/tabelas/custos",
			"/_authenticated/tabelas/precos",
			"/_authenticated/relatorios/"
		],
		preloads: [
			"/assets/route-bGHEzams.js",
			"/assets/button-b2dqjJB2.js",
			"/assets/createLucideIcon-DeQrcgrh.js",
			"/assets/truck-gxs4VXd5.js",
			"/assets/clipboard-list-Cmh-2VMV.js",
			"/assets/log-out-DoLQqS8K.js",
			"/assets/wallet-DkdjQM1w.js",
			"/assets/x-DSHPaOOl.js",
			"/assets/dist-Cyq2gE0m.js"
		]
	},
	"/auth": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-7F8HZC2A.js",
			"/assets/button-b2dqjJB2.js",
			"/assets/input-BQh79WNK.js",
			"/assets/dist-oL771VFr.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/dist-5uUCy-3J.js",
			"/assets/dist-lsUx7UVj.js"
		]
	},
	"/_authenticated/configuracoes": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/configuracoes.tsx",
		children: void 0,
		preloads: ["/assets/configuracoes-D2B3yCsJ.js", "/assets/page-header--CG31WIe.js"]
	},
	"/_authenticated/dashboard": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-BXbBhJAq.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/pencil-Hsojz1o8.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/animated-page-DEr0CE_U.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/cadastros/hoteis": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/cadastros/hoteis.tsx",
		children: void 0,
		preloads: [
			"/assets/hoteis-DBttcBCo.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/pencil-Hsojz1o8.js",
			"/assets/plus-psvog1OK.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/dialog-BwEDc8uH.js"
		]
	},
	"/_authenticated/cadastros/pecas": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/cadastros/pecas.tsx",
		children: void 0,
		preloads: [
			"/assets/pecas-zEXLucBj.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/pencil-Hsojz1o8.js",
			"/assets/plus-psvog1OK.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/dialog-BwEDc8uH.js"
		]
	},
	"/_authenticated/cadastros/prestadoras": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/cadastros/prestadoras.tsx",
		children: void 0,
		preloads: [
			"/assets/prestadoras-Bv9vxCKg.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/pencil-Hsojz1o8.js",
			"/assets/plus-psvog1OK.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/dialog-BwEDc8uH.js",
			"/assets/switch-DHeDfqCL.js"
		]
	},
	"/_authenticated/financeiro/cobrancas": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/financeiro/cobrancas.tsx",
		children: void 0,
		preloads: [
			"/assets/cobrancas-BBhSNDwr.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/financeiro/pagamentos": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/financeiro/pagamentos.tsx",
		children: void 0,
		preloads: [
			"/assets/pagamentos-BnzBcc9Q.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/operacao/conferencia": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/operacao/conferencia.tsx",
		children: void 0,
		preloads: [
			"/assets/conferencia-BraxsG2d.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/save-Do-q-0zI.js"
		]
	},
	"/_authenticated/operacao/roll-alyani": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/operacao/roll-alyani.tsx",
		children: ["/_authenticated/operacao/roll-alyani/$id"],
		preloads: [
			"/assets/roll-alyani-Aq58wVPz.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/pencil-Hsojz1o8.js",
			"/assets/plus-psvog1OK.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/trash-2-D8KVMNrq.js",
			"/assets/dialog-BwEDc8uH.js",
			"/assets/switch-DHeDfqCL.js",
			"/assets/animated-page-DEr0CE_U.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/operacao/roll-prestadora": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/operacao/roll-prestadora.tsx",
		children: ["/_authenticated/operacao/roll-prestadora/$id"],
		preloads: [
			"/assets/roll-prestadora-CZ9wHVZH.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/pencil-Hsojz1o8.js",
			"/assets/plus-psvog1OK.js",
			"/assets/filter-bar-C5_dEE2n.js",
			"/assets/trash-2-D8KVMNrq.js",
			"/assets/dialog-BwEDc8uH.js",
			"/assets/animated-page-DEr0CE_U.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/relatorios/hotel": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/relatorios/hotel.tsx",
		children: void 0,
		preloads: [
			"/assets/hotel-CBPREwA9.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/printer--2PazsfP.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/tabelas/custos": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/tabelas/custos.tsx",
		children: void 0,
		preloads: [
			"/assets/custos-D75u5Pdz.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/save-Do-q-0zI.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/tabelas/precos": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/tabelas/precos.tsx",
		children: void 0,
		preloads: [
			"/assets/precos-Bfs6loEY.js",
			"/assets/useQuery-jsIgwVIu.js",
			"/assets/useMutation-CG16fObi.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/input-BQh79WNK.js",
			"/assets/label-r2F2mZyM.js",
			"/assets/select-CubNlq4t.js",
			"/assets/save-Do-q-0zI.js",
			"/assets/format-BDHwEjtS.js"
		]
	},
	"/_authenticated/relatorios/": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/relatorios/index.tsx",
		children: void 0,
		preloads: [
			"/assets/relatorios-BYpOzRK-.js",
			"/assets/page-header--CG31WIe.js",
			"/assets/printer--2PazsfP.js"
		]
	},
	"/_authenticated/operacao/roll-alyani/$id": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/operacao/roll-alyani.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/roll-alyani._id-G6LQ-KK-.js",
			"/assets/arrow-left-DWsA1N-W.js",
			"/assets/save-Do-q-0zI.js"
		]
	},
	"/_authenticated/operacao/roll-prestadora/$id": {
		filePath: "C:/Users/Biel Carreon/Documents/ALYANI-ARQUIVO-EDITADO-POR-IA/src/routes/_authenticated/operacao/roll-prestadora.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/roll-prestadora._id-DMMaM7wK.js",
			"/assets/arrow-left-DWsA1N-W.js",
			"/assets/save-Do-q-0zI.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
